# basic-theme

Beamer theme designed for my two institions, MINES Paristech and Institut Curie (**unofficial**).

Huge learning curve on template design. Based on the excellent explanations given [here](https://tex.stackexchange.com/questions/146529/design-a-custom-beamer-theme-from-scratch)


![mines-screenshot1](http://jcboyd.github.io/assets/basic-theme/mines-screenshot1.png)
![mines-screenshot2](http://jcboyd.github.io/assets/basic-theme/mines-screenshot2.png)

