./imgs contains the RGB images as [red signal + phase contrast, green signal + phase contrast, phase contrast]. 

./annotations contains two masks per image, one for living Raji cells and one for dead Raji cells